<?php
add_action( 'after_setup_theme', 'blankslate_setup' );
function blankslate_setup() {
    load_theme_textdomain( 'blankslate', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'html5', array( 'search-form', 'navigation-widgets' ) );
    add_theme_support( 'woocommerce' );
    global $content_width;
    if ( !isset( $content_width ) ) { $content_width = 1920; }
    register_nav_menus( array( 'main-menu' => esc_html__( 'Main Menu', 'blankslate' ) ) );

    add_theme_support(
        'custom-logo',
        array(
          'height'      => 250,
          'width'       => 250,
          'flex-width'  => true,
          'flex-height' => true,
        )
    );
}

add_action( 'admin_notices', 'blankslate_notice' );
function blankslate_notice() {
    $user_id = get_current_user_id();
    $admin_url = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http' ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $param = ( count( $_GET ) ) ? '&' : '?';
    if ( !get_user_meta( $user_id, 'blankslate_notice_dismissed_8' ) && current_user_can( 'manage_options' ) )
        echo '<div class="notice notice-info"><p><a href="' . esc_url( $admin_url ), esc_html( $param ) . 'dismiss" class="alignright" style="text-decoration:none"><big>' . esc_html__( 'Ⓧ', 'blankslate' ) . '</big></a>' . wp_kses_post( __( '<big><strong>📝 Thank you for using BlankSlate!</strong></big>', 'blankslate' ) ) . '<br /><br /><a href="https://wordpress.org/support/theme/blankslate/reviews/#new-post" class="button-primary" target="_blank">' . esc_html__( 'Review', 'blankslate' ) . '</a> <a href="https://github.com/tidythemes/blankslate/issues" class="button-primary" target="_blank">' . esc_html__( 'Feature Requests & Support', 'blankslate' ) . '</a> <a href="https://calmestghost.com/donate" class="button-primary" target="_blank">' . esc_html__( 'Donate', 'blankslate' ) . '</a></p></div>';
}

add_action( 'admin_init', 'blankslate_notice_dismissed' );
function blankslate_notice_dismissed() {
    $user_id = get_current_user_id();
    if ( isset( $_GET['dismiss'] ) )
        add_user_meta( $user_id, 'blankslate_notice_dismissed_8', 'true', true );
}

add_action( 'wp_enqueue_scripts', 'blankslate_enqueue' );
function blankslate_enqueue() {
    wp_enqueue_style( 'blankslate-style', get_stylesheet_uri() );
    wp_enqueue_style('bs-header', get_stylesheet_directory_uri() . '/assets/css/header.css');
    wp_enqueue_style('bs-content', get_stylesheet_directory_uri() . '/assets/css/content.css');
    wp_enqueue_script( 'jquery' );
}

add_action( 'wp_footer', 'blankslate_footer' );
function blankslate_footer() {
?>
    <script>
    jQuery(document).ready(function($) {
        var deviceAgent = navigator.userAgent.toLowerCase();
        if (deviceAgent.match(/(iphone|ipod|ipad)/)) {
            $("html").addClass("ios");
            $("html").addClass("mobile");
        }
        if (deviceAgent.match(/(Android)/)) {
            $("html").addClass("android");
            $("html").addClass("mobile");
        }
        if (navigator.userAgent.search("MSIE") >= 0) {
            $("html").addClass("ie");
        }
        else if (navigator.userAgent.search("Chrome") >= 0) {
            $("html").addClass("chrome");
        }
        else if (navigator.userAgent.search("Firefox") >= 0) {
            $("html").addClass("firefox");
        }
        else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
            $("html").addClass("safari");
        }
        else if (navigator.userAgent.search("Opera") >= 0) {
            $("html").addClass("opera");
        }
    });
    </script>
<?php
}

add_filter( 'document_title_separator', 'blankslate_document_title_separator' );
function blankslate_document_title_separator( $sep ) {
    $sep = esc_html( '|' );
    return $sep;
}

add_filter( 'the_title', 'blankslate_title' );
function blankslate_title( $title ) {
    if ( $title == '' ) {
        return esc_html( '...' );
    } else {
        return wp_kses_post( $title );
    }
}

function blankslate_schema_type() {
    $schema = 'https://schema.org/';
    if ( is_single() ) {
        $type = "Article";
    } elseif ( is_author() ) {
        $type = 'ProfilePage';
    } elseif ( is_search() ) {
        $type = 'SearchResultsPage';
    } else {
        $type = 'WebPage';
    }
    echo 'itemscope itemtype="' . esc_url( $schema ) . esc_attr( $type ) . '"';
}

add_filter( 'nav_menu_link_attributes', 'blankslate_schema_url', 10 );
function blankslate_schema_url( $atts ) {
    $atts['itemprop'] = 'url';
    return $atts;
}

if ( !function_exists( 'blankslate_wp_body_open' ) ) {
    function blankslate_wp_body_open() {
    do_action( 'wp_body_open' );
    }
}

add_action( 'wp_body_open', 'blankslate_skip_link', 5 );
function blankslate_skip_link() {
    echo '<a href="#content" class="skip-link screen-reader-text">' . esc_html__( 'Skip to the content', 'blankslate' ) . '</a>';
}

add_filter( 'the_content_more_link', 'blankslate_read_more_link' );
function blankslate_read_more_link() {
    if ( !is_admin() ) {
    return ' <a href="' . esc_url( get_permalink() ) . '" class="more-link">' . sprintf( __( '...%s', 'blankslate' ), '<span class="screen-reader-text">  ' . esc_html( get_the_title() ) . '</span>' ) . '</a>';
    }
}

add_filter( 'excerpt_more', 'blankslate_excerpt_read_more_link' );
function blankslate_excerpt_read_more_link( $more ) {
    if ( !is_admin() ) {
    global $post;
    return ' <a href="' . esc_url( get_permalink( $post->ID ) ) . '" class="more-link">' . sprintf( __( '...%s', 'blankslate' ), '<span class="screen-reader-text">  ' . esc_html( get_the_title() ) . '</span>' ) . '</a>';
    }
}

add_filter( 'big_image_size_threshold', '__return_false' );

add_filter( 'intermediate_image_sizes_advanced', 'blankslate_image_insert_override' );
function blankslate_image_insert_override( $sizes ) {
    unset( $sizes['medium_large'] );
    unset( $sizes['1536x1536'] );
    unset( $sizes['2048x2048'] );
    return $sizes;
}

add_action( 'widgets_init', 'blankslate_widgets_init' );
function blankslate_widgets_init() {
    register_sidebar( 
        array(
            'name' => esc_html__( 'Sidebar Widget Area', 'blankslate' ),
            'id' => 'primary-widget-area',
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        )
    );

    register_sidebar( 
        array(
            'name' => esc_html__( 'Social Widget Area', 'blankslate' ),
            'id' => 'social-widget-area',
            'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ) 
    );
}

add_action( 'wp_head', 'blankslate_pingback_header' );
function blankslate_pingback_header() {
    if ( is_singular() && pings_open() ) {
    printf( '<link rel="pingback" href="%s" />' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
    }
}

add_action( 'comment_form_before', 'blankslate_enqueue_comment_reply_script' );
function blankslate_enqueue_comment_reply_script() {
    if ( get_option( 'thread_comments' ) ) {
    wp_enqueue_script( 'comment-reply' );
    }
}

function blankslate_custom_pings( $comment ) {
?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>"><?php echo esc_url( comment_author_link() ); ?></li>
<?php
}
add_filter( 'get_comments_number', 'blankslate_comment_count', 0 );
function blankslate_comment_count( $count ) {
    if ( !is_admin() ) {
    global $id;
    $get_comments = get_comments( 'status=approve&post_id=' . $id );
    $comments_by_type = separate_comments( $get_comments );
    return count( $comments_by_type['comment'] );
    } else {
    return $count;
    }
}

// CUSTOM ADDED FOR DATAON

/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
    require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );


function wpb_custom_new_menu() {
    register_nav_menu('footer_block_1',__( 'Footer Block 1' ));
    register_nav_menu('footer_block_2',__( 'Footer Block 2' ));
    register_nav_menu('footer_block_3',__( 'Footer Block 3' ));
    register_nav_menu('footer_block_4',__( 'Footer Block 4' ));
}
  
add_action( 'init', 'wpb_custom_new_menu' );

// ACF blocks
require get_template_directory() . '/modules/acf-blocks/acf-blocks.php';

// Options page
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page();
}

/*|----------------------------------------------------------------------------------------------------
* | CPT, Tax
* |----------------------------------------------------------------------------------------------------  
*/
add_action( 'init', 'dataon_register_cpt_product' );

function dataon_register_cpt_product() {

    $labels = array(
        'name' => __( 'Product', 'product' ),
        'singular_name' => __( 'Product', 'product' ),
        'add_new' => __( 'Add New Product', 'product' ),
        'add_new_item' => __( 'Add new Product', 'product' ),
        'edit_item' => __( 'Edit Product', 'product' ),
        'new_item' => __( 'New Product', 'product' ),
        'view_item' => __( 'View Product', 'product' ),
        'search_items' => __( 'Search Product', 'product' ),
        'not_found' => __( 'Product not Found !', 'product' ),
        'not_found_in_trash' => __( 'Product not found in Trash !', 'product' ),
        'parent_item_colon' => __( 'Product', 'product' ),
        'menu_name' => __( 'Product', 'product' ),
    );
    
    $args = array(
        'labels' => $labels,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-schedule',
        'public' => true,
        'taxonomies' => array('product_category'),
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','editor','thumbnail', 'page-attributes', 'excerpt', 'author' )
    );

    register_post_type( 'product', $args );
}


add_action( 'init', 'dataon_register_cpt_documents' );

function dataon_register_cpt_documents() {

    $labels = array(
        'name' => __( 'Document', 'document' ),
        'singular_name' => __( 'Document', 'document' ),
        'add_new' => __( 'Add New Document', 'document' ),
        'add_new_item' => __( 'Add new Document', 'document' ),
        'edit_item' => __( 'Edit Document', 'document' ),
        'new_item' => __( 'New Document', 'document' ),
        'view_item' => __( 'View Document', 'document' ),
        'search_items' => __( 'Search Document', 'document' ),
        'not_found' => __( 'Document not Found !', 'document' ),
        'not_found_in_trash' => __( 'Document not found in Trash !', 'document' ),
        'parent_item_colon' => __( 'Document', 'document' ),
        'menu_name' => __( 'Document', 'document' ),
    );
    
    $args = array(
        'labels' => $labels,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-schedule',
        'public' => true,
        'taxonomies' => array('product_category'),
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','editor','thumbnail', 'page-attributes', 'excerpt' )
    );

    register_post_type( 'document', $args );
}




function dataon_document_taxonomy() {  
    register_taxonomy(  
        'document_category',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'document', // post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Document Categories',  //Display name
            'query_var' => true,
            'rewrite'   => array( 'slug' => 'document_cat' ),
            'show_ui' => true,
            'show_in_rest' => true,        
        )  
    );  
}  
add_action( 'init', 'dataon_document_taxonomy');






// Customer stories cpt
add_action( 'init', 'dataon_register_cpt_customer_stories' );

function dataon_register_cpt_customer_stories() {

    $labels = array(
        'name' => __( 'Customer Stories', 'customer-stories' ),
        'singular_name' => __( 'Customer Story', 'customer-stories' ),
        'add_new' => __( 'Add New Customer Story', 'customer-stories' ),
        'add_new_item' => __( 'Add new Customer Story', 'customer-stories' ),
        'edit_item' => __( 'Edit Customer Story', 'customer-stories' ),
        'new_item' => __( 'New Customer Story', 'customer-stories' ),
        'view_item' => __( 'View Customer Story', 'customer-stories' ),
        'search_items' => __( 'Search Customer Stories', 'customer-stories' ),
        'not_found' => __( 'Customer Story not Found !', 'customer-stories' ),
        'not_found_in_trash' => __( 'Customer Story not found in Trash !', 'customer-stories' ),
        'parent_item_colon' => __( 'Customer Story', 'customer-stories' ),
        'menu_name' => __( 'Customer Stories', 'customer-stories' ),
    );
    
    $args = array(
        'labels' => $labels,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-format-status',
        'public' => true,
        'taxonomies' => array('customer-stories-category'),
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','editor','thumbnail', 'page-attributes', 'excerpt', 'author', 'customer-stories')
    );

    register_post_type( 'customer-stories', $args );
}

function dataon_customer_stories_taxonomy() {  
    register_taxonomy(  
        'customer-stories-category',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'customer-stories', // post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Customer Stories Categories',  // Display name
            'query_var' => true,
            'show_in_rest' => true,
            'rewrite'   => array( 'slug' => 'customer-stories-category' )            
        )  
    );  
}  
add_action( 'init', 'dataon_customer_stories_taxonomy');










// Customer stories cpt
add_action( 'init', 'dataon_register_cpt_knowledge_base' );

function dataon_register_cpt_knowledge_base() {

    $labels = array(
        'name' => __( 'Knowledge Base', 'knowledge-base' ),
        'singular_name' => __( 'Knowledge Base', 'knowledge-base' ),
        'add_new' => __( 'Add New Knowledge Base item', 'knowledge-base' ),
        'add_new_item' => __( 'Add new Knowledge Base item', 'knowledge-base' ),
        'edit_item' => __( 'Edit Knowledge Base', 'knowledge-base' ),
        'new_item' => __( 'New Knowledge Base', 'knowledge-base' ),
        'view_item' => __( 'View Knowledge Base', 'knowledge-base' ),
        'search_items' => __( 'Search Knowledge Base', 'knowledge-base' ),
        'not_found' => __( 'Knowledge Base not Found !', 'knowledge-base' ),
        'not_found_in_trash' => __( 'Knowledge Base not found in Trash !', 'knowledge-base' ),
        'parent_item_colon' => __( 'Knowledge Base', 'knowledge-base' ),
        'menu_name' => __( 'Knowledge Base', 'knowledge-base' ),
    );
    
    $args = array(
        'labels' => $labels,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-format-status',
        'public' => true,
        'taxonomies' => array('knowledge-base'),
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','thumbnail', 'page-attributes', 'excerpt', 'author', 'knowledge-base')
    );

    register_post_type( 'knowledge-base', $args );
}

function dataon_knowledge_base_taxonomy() {  
    register_taxonomy(  
        'knowledge-base-categories',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'knowledge-base', // post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Knowledge Base Categories',  // Display name
            'query_var' => true,
            'show_in_rest' => true,
            'rewrite'   => array( 'slug' => 'knowledge-base-categories' )            
        )  
    );  
}  
add_action( 'init', 'dataon_knowledge_base_taxonomy');












// Customer stories cpt
add_action( 'init', 'dataon_register_cpt_videos' );

function dataon_register_cpt_videos() {

    $labels = array(
        'name' => __( 'Videos', 'dataon-videos' ),
        'singular_name' => __( 'Video', 'dataon-videos' ),
        'add_new' => __( 'Add New Video', 'dataon-videos' ),
        'add_new_item' => __( 'Add new Video', 'dataon-videos' ),
        'edit_item' => __( 'Edit Video', 'dataon-videos' ),
        'new_item' => __( 'New Video', 'dataon-videos' ),
        'view_item' => __( 'View Video', 'dataon-videos' ),
        'search_items' => __( 'Search Video', 'dataon-videos' ),
        'not_found' => __( 'Video not Found !', 'dataon-videos' ),
        'not_found_in_trash' => __( 'CVideo not found in Trash !', 'dataon-videos' ),
        'parent_item_colon' => __( 'Video', 'dataon-videos' ),
        'menu_name' => __( 'Videos', 'dataon-videos' ),
    );
    
    $args = array(
        'labels' => $labels,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-format-status',
        'public' => true,
        'taxonomies' => array('dataon-videos-category'),
        'has_archive' => true,
        'show_in_rest' => true,
        'supports' => array('title','thumbnail', 'page-attributes', 'dataon-videos')
    );

    register_post_type( 'dataon-videos', $args );
}

function dataon_videos_taxonomy() {  
    register_taxonomy(  
        'dataon-videos-category',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        'dataon-videos', // post type name
        array(  
            'hierarchical' => true,  
            'label' => 'Video Categories',  // Display name
            'query_var' => true,
            'show_in_rest' => true,
            'rewrite'   => array( 'slug' => 'dataon-videos-category' )            
        )  
    );  
}  
add_action( 'init', 'dataon_videos_taxonomy');













// CUSTOM ADMIN PAGE FOR ANALYTICS 

add_action( 'admin_menu', 'my_admin_menu' );

function my_admin_menu() {
	add_menu_page( 'Analytics', 'Analytics', 'manage_options', 'admin-analytics.php', 'myplguin_admin_page', 'dashicons-tickets', 6  );
}

function myplguin_admin_page(){
	?>

<style>

table 
{
    width: 60%;
    padding: 20px;
    margin-top: 50px;
    text-align: left;
    border-collapse: collapse;
}

th 
{
    font-size: 20px;
    padding: 10px;
}

tr:nth-child(even)
{
    background: #ebebeb;
}

td 
{
    padding: 5px 10px;
}

a 
{
    text-decoration: none;
}

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons that are used to open the tab content */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 20px;
  margin-right: 20px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
  margin-bottom: 100px;
}

.chartSection 
{
    width: 35%;
    margin: 50px 20px;
}

#pdf.tabcontent
{
    display: flex;
}

.section 
{
    margin-bottom: 100px;
}

.vid-analytics
{
    margin: 50px 0px;
    width: 30%;
    padding: 20px;
}

.vid-analytics h2
{
    font-size: 23px;
    line-height: normal;
}

#videos 
{
    max-width: 2000px;
}

.landing 
{
    width: 40%;
    margin: 20px;
}

</style>


<script>
function openCity(evt, cityName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

</script>



<div class="wrap">
		<h2 style="font-size: 30px; margin-bottom: 30px;">Analytics</h2>
	</div>

<div class="tab">
  <button class="tablinks active" onclick="openCity(event, 'pdf')">PDF \ Files</button>
  <button class="tablinks" onclick="openCity(event, 'videos')">Videos</button>
  <button class="tablinks" onclick="openCity(event, 'landing')">Landing Pages</button>
</div>


<div class="tabcontent" id="pdf" style="display: block;">

<div style='display: flex;'>

    <table>
        <tr>
            <th>PDF</th>
            <th>Pages</th>
            <th>Clicks</th>
            <th>ID</th>
        </tr>

<?php $the_query = new WP_Query(
    array(
    'post_type' => 'attachment',
    'post_status' => 'inherit',
    'posts_per_page' => -1,
    'post_mime_type' => 'application/pdf',
    'orderby' => 'date'
    ));


// The Loop.
if ( $the_query->have_posts() ) {
    echo '<tr>';


	while ( $the_query->have_posts() ) {
		$the_query->the_post();
        $imgurl = wp_get_attachment_url( get_the_ID() );

        $esting = get_the_ID();

        echo '<td>';
        echo '<ul>';

		echo '<li><a target="_blank" href="' . $imgurl . '"> ' . esc_html( get_the_title() ) . '</a></li>';

        echo '</ul>';
        echo '</td>';

        echo '<td>';
        echo '<a href="#">POST URL</a>';
        echo '</td>';

        echo '<td>';
        $attachment_id = $esting;
        echo $attachment_id;
        $parent = get_post_ancestors( $attachment_id );
        echo 'here' . $parent[0]; // $parent will be an array
        print_r($parent);
        echo '</td>';

        echo '<td>';
        $esting = get_the_ID();
        echo $esting;
        echo '</td>';


        echo '</tr>';
    }
} else {
	esc_html_e( 'Sorry, no posts matched your criteria.' );
}
?>

</table>


<div class='chartSection'>

    <div class="section chartHistorical">
        <h2>Historical Clicks</h2>
        <canvas id="myChart"></canvas>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <script>
        const ctx = document.getElementById('myChart');

        new Chart(ctx, {
            type: 'bar',
            data: {
            labels: ['Azure Stack HCI Datasheet_April 2022', 'vgpu-a16-datasheet-feb-2022', 'DataON Hybrid Cloud Solutions for Azure Stack HCI_July 2021', 'Azure Stack HCI Datasheet_April 2022', 'DataON MUST for Windows Admin Center_Dec 2020', 'DataON_DNS-4524_Storage_Enclosure_Datasheet'],
            datasets: [{
                label: '# of Clicks',
                data: [40, 29, 23, 78, 52, 33],
                borderWidth: 1
            }]
            },
            options: {
            scales: {
                y: {
                beginAtZero: true
                }
            }
            }
        });
        </script>

    </div>




    <div class="section chart24">
        <h2>Last 24 Hours</h2>
        <canvas id="chart24"></canvas>


        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <script>
        const ctxHistorical = document.getElementById('chart24');

        new Chart(ctxHistorical, {
            type: 'bar',
            data: {
            labels: ['Azure Stack HCI Datasheet_April 2022', 'vgpu-a16-datasheet-feb-2022', 'DataON Hybrid Cloud Solutions for Azure Stack HCI_July 2021', 'Azure Stack HCI Datasheet_April 2022', 'DataON MUST for Windows Admin Center_Dec 2020', 'DataON_DNS-4524_Storage_Enclosure_Datasheet'],
            datasets: [{
                label: '# of Clicks',
                data: [1, 9, 2, 5, 6, 1],
                borderWidth: 1
            }]
            },
            options: {
            scales: {
                y: {
                beginAtZero: true
                }
            }
            }
        });
        </script>

    </div>


</div>

</div>

</div>



<div id="videos" class="tabcontent">

<h2>Videos</h2>

<?php $videos_query = new WP_Query(
    array(
    'post_type' => 'dataon-videos',
    'posts_per_page' => -1,
    'orderby' => 'date'
    )); ?>

    <div style="display: flex; flex-wrap: wrap;">


    <?php if ( $videos_query->have_posts() ) { ?>
    
    
      <?php while ( $videos_query->have_posts() ) {
            $videos_query->the_post(); ?>

            <div class="vid-analytics">

                    <h2><?php the_title(); ?></h2>
                    <?php echo '<iframe width="100%" height="300px" src="https://www.youtube.com/embed/' . esc_html( get_field("youtube_video_url") ) . '" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>'; ?>

                    <div class="video-stats">
                        <table style="width: 100%; margin-top: 0px;">
                            <tr>
                                <td>
                                    <h3>Total Views</h3>
                                </td>
                                <td>
                                    89
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <h3>Top Pages</h3>
                                </td>
                                <td>
                                    <ul>
                                        <li>https://dataon.wpengine.com/product/k2n-47-g2-two-node-hyper-converged-appliance-for-microsoft-azure-stack-hci-solution/</li>
                                        <li>https://dataon.wpengine.com/product/jbod-enclosure/</li>
                                        <li>https://dataon.wpengine.com/product/dns-4524/</li>
                                        <li>https://dataon.wpengine.com/backup-and-disaster-recovery/</li>
                                    <ul>
                                </td>
                            </tr>

                        </table>

                    </div>

            </div>

       <?php }


    } else {
        esc_html_e( 'Sorry, no posts matched your criteria.' );
    } ?>
    
       
</div>

</div>


<div id="landing" class="tabcontent">


<div style="display: flex; flex-wrap: wrap;">


<div class="landing one">

    <h2 style="font-size: 22px; margin-bottom: 0px;">Home Page</h2>
    <div class="url">https://dataon.wpengine.com/</div>
    <img width="500px" src="https://dataon.wpengine.com/wp-content/uploads/2023/09/DataON-2023-09-08-10-44-11.png" />
    <div class="views">
        <h3>Total Views (Month)</h3>
        <div>820</div>
    </div>
    <div class="refers">
        <h3>Top referrer links:</h3>
        <ul>
            <li>https://www.dell.com/en-us</li>
            <li>https://www.google.com/</li>
            <li>https://www.semrush.com/</li>
        </ul>
    </div>
    <div class="cta">
        <h3>CTA Info</h3>

        <div class="cta one">
            <h4>CTA Title</h4>
            <div class="">
                Number of Clicks: 108
            </div>
        </div>

    </div>


</div>

<div class="landing two">

    <h2 style="font-size: 22px; margin-bottom: 0px;">Products</h2>
    <div class="url">https://dataon.wpengine.com/products/</div>
    <img width="500px" src="https://dataon.wpengine.com/wp-content/uploads/2023/09/Products-DataON-2023-09-08-10-48-45.png" />
    <div class="views">
        <h3>Total Views (Month)</h3>
        <div>960</div>
    </div>
    <div class="refers">
        <h3>Top referrer links:</h3>
        <ul>
            <li>https://www.dell.com/en-us</li>
            <li>https://www.google.com/</li>
            <li>https://www.semrush.com/</li>
        </ul>
    </div>
    <div class="cta">
        <h3>CTA Info</h3>

        <div class="cta one">
            <h4>CTA Title</h4>
            <div class="">
                Number of Clicks: 108
            </div>
        </div>

    </div>


</div>

<div class="landing three">

    <h2 style="font-size: 22px; margin-bottom: 0px;">Technology Partners</h2>
    <div class="url">https://dataon.wpengine.com/company/technology-partners/</div>
    <img width="500px" src="https://dataon.wpengine.com/wp-content/uploads/2023/09/Technology-Partners-DataON-2023-09-08-10-46-42.png" />
    <div class="views">
        <h3>Total Views (Month)</h3>
        <div>1190</div>
    </div>
    <div class="refers">
        <h3>Top referrer links:</h3>
        <ul>
            <li>https://www.dell.com/en-us</li>
            <li>https://www.google.com/</li>
            <li>https://www.semrush.com/</li>
        </ul>
    </div>
    <div class="cta">
        <h3>CTA Info</h3>

        <div class="cta one">
            <h4>CTA Title</h4>
            <div class="">
                Number of Clicks: 108
            </div>
        </div>

        <div class="cta two">
            <h4>CTA Title</h4>
            <div class="">
                Number of Clicks: 317
            </div>
        </div>

    </div>


</div>

</div>



</div>


<?php 
// Restore original Post Data.
wp_reset_postdata();

}





function misha_my_load_more_scripts() {
 
	global $wp_query; 
 
	// In most cases it is already included on the page and this line can be removed
	wp_enqueue_script('jquery');
 
	// register our main script but do not enqueue it yet
	wp_register_script( 'my_loadmore', get_stylesheet_directory_uri() . '/myloadmore.js', array('jquery') );
 
	// now the most interesting part
	// we have to pass parameters to myloadmore.js script but we can get the parameters values only in PHP
	// you can define variables directly in your HTML but I decided that the most proper way is wp_localize_script()
	wp_localize_script( 'my_loadmore', 'misha_loadmore_params', array(
		'ajaxurl' => site_url() . '/wp-admin/admin-ajax.php', // WordPress AJAX
		'posts' => json_encode( $wp_query->query_vars ), // everything about your loop is here
		'current_page' => get_query_var( 'paged' ) ? get_query_var('paged') : 1,
		'max_page' => $wp_query->max_num_pages
	) );
 
 	wp_enqueue_script( 'my_loadmore' );
}
 
add_action( 'wp_enqueue_scripts', 'misha_my_load_more_scripts' );






function misha_loadmore_ajax_handler(){
 

	// prepare our arguments for the query
	$args = json_decode( stripslashes( $_POST['query'] ), true );
	$args['paged'] = $_POST['page'] + 1; // we need next page to be loaded
	$args['post_status'] = 'publish';
 
	// it is always better to use WP_Query but not here
	query_posts( $args );
 
	if( have_posts() ) :
 
		// run the loop
		while( have_posts() ): the_post();
 
			// look into your theme code how the posts are inserted, but you can use your own HTML of course
			// do you remember? - my example is adapted for Twenty Seventeen theme
			// get_template_part( 'template-parts/post/content', get_post_format() );
			// for the test purposes comment the line above and uncomment the below one
			// the_title();
           //  echo "testing"; ?>


        <article id="post-<?php the_ID(); ?>" <?php post_class( 'col-lg-4 post'); ?>>
            <div class="row">
                <div class="col-12">
                    <?php
                    $postID = get_the_ID(); 
                    $postImage = get_the_post_thumbnail_url($postID, 'full');
                    if(empty($postImage)) {
                        $postImage = 'https://dataon.io/wp-content/uploads/2024/02/DataON-default-image-1600x900-1.jpg';
                    }
                    ?>

                    <div class="post-img" style="background-size: cover; background-image: url(<?php echo $postImage; ?>);"></div>
                </div>
                <div class="col-12 col-post-content">
                    <header>
                    <!-- <div class="post-cat">
                        <?php $categories = get_the_category();
                            if ( ! empty( $categories ) ) { ?>
                            <h5><?php echo esc_html( $categories[0]->name ); ?></h5>	
                        <?php } ?>
                    </div> -->
                    <h2 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
                            <?php // edit_post_link(); ?>
                            <a href="<?php the_permalink(); ?>">Read more</a>
                        </header>
                        <?php 
                    //	echo get_the_excerpt(); 
                        ?>
                        <?php if ( is_singular() ) { get_template_part( 'entry-footer' ); } ?>
                </div>
            </div>
        </article>

		<?php endwhile;
 
	endif;
	die; // here we exit the script and even no wp_reset_query() required!
}
 
 
 
add_action('wp_ajax_loadmore', 'misha_loadmore_ajax_handler'); // wp_ajax_{action}
add_action('wp_ajax_nopriv_loadmore', 'misha_loadmore_ajax_handler'); // wp_ajax_nopriv_{action}


function filter_projects() {

    $catSlug = $_POST['category'];

    if ($catSlug === 'blog'){
        $ajaxposts = new WP_Query([
            'post_type'      => 'post',
            'posts_per_page' => 100,
            'offset' => 2,
        ]);
    } else {
        $ajaxposts = new WP_Query([
              'posts_per_page' => -1,
              'tax_query' => array(
                array (
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $catSlug,
                )),
              'orderby' => 'menu_order', 
              'order' => 'desc',
            ]);
    }

  
    if($ajaxposts->have_posts()) {
      while($ajaxposts->have_posts()) : $ajaxposts->the_post();
        $response .= get_template_part('templates/category-ajax-posts');
      endwhile;
    } else {
      $response = 'empty';
    }
  
    echo $response;
    exit;
  }
  add_action('wp_ajax_filter_projects', 'filter_projects');
  add_action('wp_ajax_nopriv_filter_projects', 'filter_projects');





  function filter_customer_stories() {

    $catSlug = $_POST['category'];

    if ($catSlug === 'blog'){
        $ajaxposts = new WP_Query([
            'post_type'      => 'customer-stories',
            'posts_per_page' => 100,
            'offset' => 2,
        ]);
    } else {
        $ajaxposts = new WP_Query([
              'posts_per_page' => -1,
              'tax_query' => array(
                array (
                    'taxonomy' => 'customer-stories-category',
                    'field' => 'slug',
                    'terms' => $catSlug,
                )),
              'orderby' => 'menu_order', 
              'order' => 'desc',
            ]);
    }

  
    if($ajaxposts->have_posts()) {
      while($ajaxposts->have_posts()) : $ajaxposts->the_post();
        $response .= get_template_part('templates/customerStories-ajax');
      endwhile;
    } else {
      $response = 'empty';
    }
  
    echo $response;
    exit;
  }
  add_action('wp_ajax_filter_customer_stories', 'filter_customer_stories');
  add_action('wp_ajax_nopriv_filter_customer_stories', 'filter_customer_stories');



  function filter_videos() {

    $catSlug = $_POST['category'];

    if ($catSlug === 'blog'){
        $ajaxposts = new WP_Query([
            'post_type'      => 'dataon-videos',
            'posts_per_page' => 100,
            'offset' => 2,
            'order' => 'desc',
        ]);
    } else {
        $ajaxposts = new WP_Query([
            'posts_per_page' => -1,
            'tax_query' => array(
                array (
                    'taxonomy' => 'dataon-videos-category',
                    'field' => 'slug',
                    'terms' => $catSlug,
                )
            ),
            'orderby' => 'menu_order', 
            'order' => 'desc',
        ]);
    }
    $response = '';
  
    if($ajaxposts->have_posts()) {
      while($ajaxposts->have_posts()) : $ajaxposts->the_post();
        $response .= get_template_part('templates/category-ajax');
      endwhile;
    } else {
      $response = 'empty';
    }
  
    echo $response;
    exit;
  }
  add_action('wp_ajax_filter_videos', 'filter_videos');
  add_action('wp_ajax_nopriv_filter_videos', 'filter_videos');



function filter_documents() {

    $catSlug = $_POST['category'];

    if ($catSlug === 'blog'){
        $ajaxposts = new WP_Query([
            'post_type'      => 'document',
            'posts_per_page' => -1,
        ]);
    } else {
        $ajaxposts = new WP_Query([
        'posts_per_page' => -1,
        'tax_query' => array(
            array (
                'taxonomy' => 'document_category',
                'field' => 'slug',
                'terms' => $catSlug,
            )),
        'orderby' => 'menu_order', 
        'order' => 'desc',
        ]);
    }
    
    $response = '';
  
    if($ajaxposts->have_posts()) {
      while($ajaxposts->have_posts()) : $ajaxposts->the_post();
        $response .= get_template_part('templates/category-ajax-doc');
      endwhile;
    } else {
      $response = 'empty';
    }
  
    echo $response;
    exit;
  }
  add_action('wp_ajax_filter_documents', 'filter_documents');
  add_action('wp_ajax_nopriv_filter_documents', 'filter_documents');



  add_filter('use_block_editor_for_post_type', 'prefix_disable_gutenberg', 10, 2);
function prefix_disable_gutenberg($current_status, $post_type)
{
    if ($post_type === 'knowledge-base') return false;
    return $current_status;
}