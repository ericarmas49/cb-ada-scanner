== Primarium ==

Contributors: Automattic
Requires at least: 6.9
Tested up to: 6.9
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This theme is a text-first notebook that showcases handwriting-inspired typography through poetic, personal writing with a clean reading flow. Inspired by the Primarium project—an open-source handwriting system by TypeTogether on Google Fonts that models primary education handwriting—it links design with pedagogical research. It suits writers who favor reflective, poetic, and personal content over traditional blog posts.

== Changelog ==

= 25 April 2026 =
* fixes translation issue (#157230)\n* Primarium:

= 6 February 2026 =
* add theme (#157096)\n* Primarium: add theme

== Copyright ==

Primarium WordPress Theme, (C) 2026 Automattic
Primarium is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Primarium is based on Ichi (https://themeshaper.com/ichi/), (C) Automattic, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)


== Fonts ==

Playwrite
Copyright 2023 The Playwrite Project Authors (https://github.com/TypeTogether/Playwrite)
License: This Font Software is licensed under the SIL Open Font License, Version 1.1 .
License URI: https://openfontlicense.org
Source: https://github.com/TypeTogether/Playwrite

== Images ==

Illustrations by Pablo Stanley (https://www.instagram.com/pablostanley/) for OpenDoodles
License: Public Domain, CC0 1.0 Universal
License URI: https://creativecommons.org/publicdomain/zero/1.0/
Source: https://www.opendoodles.com/about


